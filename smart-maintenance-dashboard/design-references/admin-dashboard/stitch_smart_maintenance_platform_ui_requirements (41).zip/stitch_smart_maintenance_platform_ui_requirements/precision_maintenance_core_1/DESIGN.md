---
name: Precision Maintenance Core
colors:
  surface: '#fbf9fa'
  surface-dim: '#dbd9db'
  surface-bright: '#fbf9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f4'
  surface-container: '#efedef'
  surface-container-high: '#e9e7e9'
  surface-container-highest: '#e4e2e3'
  on-surface: '#1b1c1d'
  on-surface-variant: '#44474c'
  inverse-surface: '#303032'
  inverse-on-surface: '#f2f0f2'
  outline: '#74777d'
  outline-variant: '#c4c6cd'
  surface-tint: '#4f6073'
  primary: '#041627'
  on-primary: '#ffffff'
  primary-container: '#1a2b3c'
  on-primary-container: '#8192a7'
  inverse-primary: '#b7c8de'
  secondary: '#545f72'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f7'
  on-secondary-container: '#586377'
  tertiary: '#211200'
  on-tertiary: '#ffffff'
  tertiary-container: '#38260b'
  on-tertiary-container: '#a88c69'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d2e4fb'
  primary-fixed-dim: '#b7c8de'
  on-primary-fixed: '#0b1d2d'
  on-primary-fixed-variant: '#38485a'
  secondary-fixed: '#d8e3fa'
  secondary-fixed-dim: '#bcc7dd'
  on-secondary-fixed: '#111c2c'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#feddb5'
  tertiary-fixed-dim: '#e1c29b'
  on-tertiary-fixed: '#281802'
  on-tertiary-fixed-variant: '#584326'
  background: '#fbf9fa'
  on-background: '#1b1c1d'
  surface-variant: '#e4e2e3'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  timer-display:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max-width: 1440px
---

## Brand & Style

The design system is engineered for industrial-grade reliability, focusing on the high-stakes environments of request management and field execution. The target audience includes maintenance coordinators and field technicians who require immediate clarity on Service Level Agreement (SLA) status and task prioritization. 

The aesthetic is **Corporate / Modern** with a lean towards **Utility**. It prioritizes information density and functional hierarchy over decorative elements. The emotional response is one of controlled urgency and professional confidence—users should feel that the system is an extension of their operational discipline. The UI uses a structured grid and a disciplined color application to ensure that critical operational data, specifically SLA compliance metrics, remains the primary focal point.

## Colors

The palette is anchored by **Deep Corporate Blue**, conveying stability and institutional authority. **Slate Gray** provides a neutral foundation for UI chrome and secondary actions, ensuring the interface feels grounded.

The **SLA Status Palette** is the most critical visual signal in the system:
- **Safe (Emerald Green):** Indicates compliance and stable timelines.
- **Near Breach (Amber Orange):** Triggers heightened awareness for pending deadlines.
- **Breached/Urgent (Crimson Red):** Denotes immediate action required or failed compliance.

Surface colors utilize a light-mode foundation with subtle cool-gray backgrounds to reduce eye strain during prolonged use, while maintaining high contrast for text legibility.

## Typography

This design system uses **Inter** exclusively to leverage its exceptional legibility and systematic character. The type scale is optimized for data-heavy dashboards and mobile field tools.

- **Headlines:** Use tight letter spacing and bold weights to establish clear section hierarchy.
- **Body:** Set at 14px for standard density, ensuring complex forms remain compact.
- **Timer Display:** A specialized style using tabular figures (`tnum`) is required for SLA countdowns to prevent layout shifting as seconds decrement.
- **Labels:** Uppercase labels are reserved for metadata headers and small status indicators to differentiate them from interactive body text.

## Layout & Spacing

The layout follows a **Fluid Grid** model with strict adherence to an 8px spacing rhythm. 

- **Desktop:** A 12-column grid with 16px gutters. Content is housed in "work cards" that span 4, 6, or 12 columns depending on the complexity of the maintenance request data.
- **Mobile:** A single-column flow with 16px side margins. Priority is given to the "Field Execution" view, where the most critical SLA timer is pinned to the top of the viewport.
- **Spacing Logic:** Vertical rhythm is maintained through multiples of 8px. Use 8px for internal component padding and 24px-32px for section separation.

## Elevation & Depth

Depth is used sparingly and purposefully to indicate interactivity and layering:

- **Level 0 (Base):** The main background surface (#F8FAFC).
- **Level 1 (Cards):** White surfaces with a 1px solid border (#E2E8F0) and a very subtle 4px blur shadow (5% opacity black). This is the standard container for request details.
- **Level 2 (Modals/Popovers):** Elevated with a 12px blur shadow (10% opacity) to focus the user on critical field entries or status changes.
- **Interactive States:** Buttons and interactive list items do not lift on hover; instead, they utilize subtle tonal shifts to maintain a "flat" and efficient industrial feel.

## Shapes

The design system employs a **Rounded** shape language with a specific focus on precision. 

- **Standard Components:** Buttons, Input Fields, and Cards all utilize a **0.5rem (8px)** corner radius.
- **Small Elements:** Status badges and checkboxes utilize a **0.25rem (4px)** radius to maintain visual weight without appearing too circular.
- **Functional Geometry:** High-visibility timers may use a 0px left-border radius if pinned to the side of a container to imply integration with the layout edge.

## Components

### Button Hierarchy
- **Primary:** Solid `#1A2B3C` with White text. Used for "Submit Request" or "Complete Work Order."
- **Secondary:** Outline `#1A2B3C` with 1px border. Used for "Edit," "View Details," or "Cancel."
- **Danger:** Outline `#EF4444` with 1px border. Used for "Report Breach" or "Delete Draft."

### Status Badges (12 SRS Statuses)
All badges use a 4px radius, 12px Semibold Inter, and a "Soft Background" style (10% opacity of the base color with 100% opacity text).
1.  **Draft:** Gray
2.  **Pending Approval:** Slate
3.  **Approved:** Blue
4.  **Assigned:** Blue
5.  **In Progress:** Blue
6.  **On Hold:** Amber
7.  **SLA Warning:** Amber
8.  **SLA Breached:** Red
9.  **Urgent:** Red
10. **Resolved:** Emerald
11. **Verified:** Emerald
12. **Closed:** Slate

### High-Visibility Timers
Timers must be displayed in a high-contrast box. If the time remaining is < 1 hour, the background should pulse subtly between the status color and a lighter tint.

### Input Fields & Lists
- **Inputs:** 8px radius, 1px border (#E2E8F0). On focus, the border thickens to 2px Primary Blue.
- **Lists:** Maintenance request lists must use "Zebra Striping" (alternating #F8FAFC and #FFFFFF) to assist with horizontal scanning of SLA data.