---
name: Precision Maintenance Core
colors:
  surface: '#fbf9fa'
  surface-dim: '#dbd9db'
  surface-bright: '#fbf9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f4'
  surface-container: '#efedef'
  surface-container-high: '#e9e7e9'
  surface-container-highest: '#e4e2e3'
  on-surface: '#1b1c1d'
  on-surface-variant: '#44474c'
  inverse-surface: '#303032'
  inverse-on-surface: '#f2f0f2'
  outline: '#74777d'
  outline-variant: '#c4c6cd'
  surface-tint: '#4f6073'
  primary: '#041627'
  on-primary: '#ffffff'
  primary-container: '#1a2b3c'
  on-primary-container: '#8192a7'
  inverse-primary: '#b7c8de'
  secondary: '#545f72'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f7'
  on-secondary-container: '#586377'
  tertiary: '#211200'
  on-tertiary: '#ffffff'
  tertiary-container: '#38260b'
  on-tertiary-container: '#a88c69'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d2e4fb'
  primary-fixed-dim: '#b7c8de'
  on-primary-fixed: '#0b1d2d'
  on-primary-fixed-variant: '#38485a'
  secondary-fixed: '#d8e3fa'
  secondary-fixed-dim: '#bcc7dd'
  on-secondary-fixed: '#111c2c'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#feddb5'
  tertiary-fixed-dim: '#e1c29b'
  on-tertiary-fixed: '#281802'
  on-tertiary-fixed-variant: '#584326'
  background: '#fbf9fa'
  on-background: '#1b1c1d'
  surface-variant: '#e4e2e3'
  sla-safe: '#10B981'
  sla-warning: '#F59E0B'
  sla-danger: '#EF4444'
  surface-muted: '#F7FAFC'
  border-subtle: '#E2E8F0'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  status-badge:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 12px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  container-margin: 16px
  gutter: 12px
  card-padding: 16px
  section-gap: 24px
---

## Brand & Style

The design system is engineered for high-stakes operational environments where clarity, speed, and reliability are paramount. It serves a multi-sided ecosystem—from residents reporting issues to technicians in the field and executives monitoring portfolios. The aesthetic is **Corporate Modern**, prioritizing a "Command Center" feel that balances enterprise-grade density with mobile-first accessibility.

### Design Principles
- **Operational Intelligence:** UI elements prioritize "at-a-glance" comprehension through data visualization and status signaling.
- **Predictive Clarity:** The interface anticipates user needs, using elevation and color to highlight time-sensitive SLA tasks.
- **Rugged Professionalism:** A structured, grid-heavy layout that feels stable and dependable, mirroring the physical maintenance services it facilitates.
- **Multimodal Efficiency:** Optimized for diverse input methods including voice, AR annotations, and high-touch gesture navigation.

## Colors

The color architecture is built around functional signaling. While the **Deep Corporate Blue** establishes brand authority, the **SLA Status Palette** takes functional precedence in the operational workflow.

- **Primary & Secondary:** Used for structural elements, navigation, and primary actions. They provide a neutral, professional backdrop that allows status colors to pop.
- **SLA Functional Palette:** These colors are reserved strictly for status. 
    - **Emerald Green (Safe):** Used for completed tasks and healthy SLA windows.
    - **Amber Orange (Near Breach):** Used for tasks requiring immediate attention.
    - **Crimson Red (Breached):** Used for critical alerts and expired timers.
- **Color Mode:** The default is a high-clarity `light` mode to ensure readability in diverse lighting conditions (e.g., technicians working outdoors or in low-light utility rooms).

## Typography

This design system utilizes **Inter** for its exceptional legibility and systematic weight distribution. The type scale is optimized for high-density data display.

- **Headlines:** Use Bold and Semi-Bold weights to create a clear hierarchy in reporting dashboards.
- **Micro-Copy:** Labels and status badges use uppercase tracking to differentiate meta-data from body content.
- **SLA Timers:** Large, tabular figures should be used for countdowns to prevent character jumping during active "Pulse" animations.
- **Mobile Adaption:** For mobile views, `display-lg` should scale down to 24px (`headline-md`) to ensure titles do not wrap excessively.

## Layout & Spacing

The system employs a **Fluid-Fixed Hybrid** grid. On mobile, the layout uses a 4-column fluid grid with 16px outer margins. On desktop, content is contained within a 12-column grid to prevent line lengths from becoming illegible.

- **Rhythm:** An 8px linear scale (with 4px increments for tight components) governs all spatial relationships.
- **Mobile-First Scaffolding:** 
    - **Top Bar:** Fixed 56px height for branding and global search.
    - **Bottom Navigation:** Persistent 64px height for primary task switching.
    - **Touch Targets:** Minimum 44x44px for all interactive elements to accommodate gloved hands or field use.
- **Drawers:** Use bottom-anchored sheets for filtering and secondary inputs on mobile to maximize one-handed reachability.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Shadows**. The design avoids heavy skeuomorphism in favor of a clean, layered approach that suggests physical priority.

- **Base Layer:** `#F7FAFC` (Surface-muted) serves as the canvas.
- **Card Layer:** White surfaces with a low-opacity, diffused shadow (`0px 4px 12px rgba(26, 43, 60, 0.08)`) are used for KPIs and maintenance requests.
- **Interactive Layer:** Floating Action Buttons (FAB) and active modals use a higher elevation shadow (`0px 8px 24px rgba(26, 43, 60, 0.15)`) to sit clearly above the scrolling content.
- **Glassmorphism (Subtle):** Used exclusively for the persistent Bottom Navigation bar (80% opacity with a 10px backdrop blur) to maintain context of the content scrolling beneath it.

## Shapes

The shape language is **Rounded**, conveying modern software approachability while maintaining professional structure.

- **Components (Buttons/Inputs):** 0.5rem (8px) radius.
- **Cards & Modals:** 1rem (16px) radius to create a distinct containerized feel.
- **Status Badges:** Fully pill-shaped (rounded-full) to distinguish them from interactive buttons or cards.
- **AR/Media Containers:** 0.5rem radius to match standard component styling.

## Components

### Buttons & Navigation
- **Primary Action:** Solid `#1A2B3C` with white text. High-contrast, 0.5rem radius.
- **Secondary Action:** Ghost style with `#4A5568` border and text.
- **Navigation:** Persistent bottom bar with icon + label. Active state uses the Primary color for the icon and a 2px top-indicator bar.

### Status Badges & SLA Timers
- **Badges:** Use a 10% opacity background of the status color with 100% opacity bold text of the same hue (e.g., Emerald text on light Emerald background).
- **SLA Pulse:** Active timers for "Near Breach" and "Breached" states should feature a subtle outer-glow pulse animation using the respective status color.

### Elevated Cards
- **KPI Cards:** Feature a top-aligned `label-md` for the metric name, a `display-lg` for the value, and an integrated **Micro-chart** (sparkline) at the bottom to show 7-day trends.
- **Task Cards:** Contain a QR code icon, a clear SLA status badge, and the primary request title.

### Input Fields & Modals
- **Inputs:** 48px minimum height for mobile. Focus state uses a 2px `#1A2B3C` border.
- **Modals:** Center-aligned on desktop; converted to "Bottom Sheets" on mobile for ergonomic data entry.
- **AR Overlays:** Transparent UI layers with high-contrast white strokes for annotating photos and videos.

### Navigation Elements
- **Action-Oriented Nav:** A prominent floating "+" button (Primary Color) for creating new maintenance requests, positioned at the bottom right of the screen.